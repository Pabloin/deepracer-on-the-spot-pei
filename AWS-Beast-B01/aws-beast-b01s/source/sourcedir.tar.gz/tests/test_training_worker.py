import pytest

@pytest.mark.sagemaker
def test_training_worker():
    assert 1 == 1
